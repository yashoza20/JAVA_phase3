package com.cognizant.AuthenticationService.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.AuthenticationService.model.ApplicationUser;
import com.cognizant.AuthenticationService.repository.AuthRepository;

@Service
public class AuthenticationService {

		@Autowired
		private AuthRepository authRepository ;
		
		public ApplicationUser findUser(String id) {
			
	   Optional<ApplicationUser> list = authRepository.findById(Integer.parseInt(id));
	      ApplicationUser db = list.get();
	return db ;
}
}
