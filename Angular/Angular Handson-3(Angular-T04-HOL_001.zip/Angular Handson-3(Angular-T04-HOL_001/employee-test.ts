import {Employee} from './employee'

const emp:Employee={
    id:3,
    name:"John",
    salary:10000,
    permanent:true,
    dept:{
        id:1,
        name:"Payroll"
    },
    skills:[
        {id:1,
        name:"HTML"},

        {id:2,
        name:"CSS"},

        {id:2,
            name:"Javascript"},
    ]

}

console.log(`Employee ID:${emp.id}`);
console.log(`Employee Name:${emp.name}`);
console.log(`Employee Salary:${emp.salary}`);
console.log(`Employee Permanent:${emp.permanent}\n`);


console.log(`Department ID:${emp.id}`);
console.log(`Department Name:${emp.name}`);

var i=0;
for(let skill of emp.skills)
{
    console.log(`skill[`,i,`]:`,skill.id,`,`,skill.name);
    i++;
}

class EmployeeTest{
    emp:Employee;

    constructor(emp:Employee)
    {
        this.emp=emp;
    }

    display():void{
        console.log("Employee : "+this.emp.id+" , "+this.emp.name+" , "+this.emp.permanent+" , "+this.emp.salary+" , "+this.emp.dept.id+" , "+this.emp.dept.name);
        var i=0;
        for(let skill of this.emp.skills)
        {
            console.log(`skill[`,i,`]:`,skill.id,`,`,skill.name);
            i++;
        }

    }

}

const employeeTest = new EmployeeTest(emp);
employeeTest.display();